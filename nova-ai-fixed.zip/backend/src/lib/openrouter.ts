const OPENROUTER_BASE = 'https://openrouter.ai/api/v1'

const MODEL_MAP: Record<string, string> = {
  chat:       'anthropic/claude-3.5-haiku',
  code:       'anthropic/claude-3.5-sonnet',
  write:      'anthropic/claude-3.5-haiku',
  analyze:    'anthropic/claude-3.5-sonnet',
  brainstorm: 'anthropic/claude-3.5-haiku',
  advice:     'anthropic/claude-3.5-haiku',
  summarize:  'anthropic/claude-3.5-haiku',
  translate:  'anthropic/claude-3.5-haiku',
  research:   'anthropic/claude-3.5-sonnet',
  search:     'anthropic/claude-3.5-haiku',
  image:      'anthropic/claude-3.5-haiku',
  vision:     'anthropic/claude-3-haiku',
}

const SYSTEM_PROMPTS: Record<string, string> = {
  chat:       'You are Nova AI, a helpful and friendly AI assistant.',
  code:       'You are Nova AI, an expert coding assistant. Write clean, well-commented code. Always use code blocks with language tags.',
  write:      'You are Nova AI, a professional writing assistant. Help users craft compelling, clear, and well-structured content.',
  analyze:    'You are Nova AI, a data analysis expert. Provide clear insights, patterns, and summaries from data.',
  brainstorm: 'You are Nova AI, a creative brainstorming partner. Generate diverse, creative ideas and build on the user\'s concepts.',
  advice:     'You are Nova AI, a thoughtful advisor. Provide practical, balanced, and actionable advice.',
  summarize:  'You are Nova AI, a summarization expert. Create concise, accurate summaries capturing key points.',
  translate:  'You are Nova AI, a multilingual translation assistant. Translate accurately while preserving tone and nuance.',
  research:   'You are Nova AI, a research assistant. Synthesize information clearly with citations and structured findings.',
  search:     'You are Nova AI. Summarize web search results clearly and concisely with source attribution.',
  image:      'You are Nova AI. Help users craft effective image generation prompts.',
  vision:     'You are Nova AI, a vision assistant. Describe and analyze images in detail.',
}

function getApiKey() {
  const key = process.env.OPENROUTER_API_KEY
  if (!key) throw new Error('OpenRouter key missing — add OPENROUTER_API_KEY to your environment variables')
  return key
}

export async function chatCompletion(
  messages: { role: string; content: string | unknown[] }[],
  mode = 'chat',
  stream = false
) {
  const model = MODEL_MAP[mode] || MODEL_MAP.chat
  const systemPrompt = SYSTEM_PROMPTS[mode] || SYSTEM_PROMPTS.chat

  const response = await fetch(`${OPENROUTER_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${getApiKey()}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://nova-ai.app',
      'X-Title': 'Nova AI',
    },
    body: JSON.stringify({
      model,
      stream,
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages,
      ],
      max_tokens: 4096,
      temperature: 0.7,
    }),
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({}))
    throw new Error(err.error?.message || `OpenRouter error: ${response.status}`)
  }

  return response
}

export async function chatCompletionText(
  messages: { role: string; content: string }[],
  mode = 'chat'
): Promise<string> {
  const res = await chatCompletion(messages, mode, false)
  const data = await res.json()
  return data.choices?.[0]?.message?.content || ''
}
