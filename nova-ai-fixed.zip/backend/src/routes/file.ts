import { Router, Request, Response } from 'express'
import multer from 'multer'
import path from 'path'

const router = Router()
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } })

const SUPPORTED = ['.pdf', '.docx', '.txt', '.csv', '.xlsx']

router.post('/', upload.single('file'), async (req: Request, res: Response) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' })

    const ext = path.extname(req.file.originalname).toLowerCase()
    if (!SUPPORTED.includes(ext)) {
      return res.status(400).json({ error: `File type not supported. Supported: ${SUPPORTED.join(', ')}` })
    }

    let text = ''
    let preview: string[][] | undefined

    if (ext === '.txt') {
      text = req.file.buffer.toString('utf-8')
    }

    else if (ext === '.pdf') {
      try {
        const pdfParse = await import('pdf-parse')
        const data = await pdfParse.default(req.file.buffer)
        text = data.text
      } catch {
        throw new Error('Failed to parse PDF')
      }
    }

    else if (ext === '.docx') {
      try {
        const mammoth = await import('mammoth')
        const result = await mammoth.extractRawText({ buffer: req.file.buffer })
        text = result.value
      } catch {
        throw new Error('Failed to parse DOCX')
      }
    }

    else if (ext === '.csv') {
      try {
        const { parse } = await import('csv-parse/sync')
        const records = parse(req.file.buffer.toString('utf-8'), {
          skip_empty_lines: true,
          relax_column_count: true,
        }) as string[][]
        preview = records.slice(0, 20)
        text = records.map((r: string[]) => r.join(', ')).join('\n')
      } catch {
        throw new Error('Failed to parse CSV')
      }
    }

    else if (ext === '.xlsx') {
      try {
        const XLSX = await import('xlsx')
        const workbook = XLSX.read(req.file.buffer, { type: 'buffer' })
        const sheet = workbook.Sheets[workbook.SheetNames[0]]
        const data = XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1 })
        preview = (data as string[][]).slice(0, 20)
        text = (data as string[][]).map((r: string[]) => r.join(', ')).join('\n')
      } catch {
        throw new Error('Failed to parse XLSX')
      }
    }

    res.json({
      name: req.file.originalname,
      type: ext,
      size: req.file.size,
      text: text.slice(0, 50000), // cap at 50k chars
      preview,
    })
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'File processing error' })
  }
})

export default router
