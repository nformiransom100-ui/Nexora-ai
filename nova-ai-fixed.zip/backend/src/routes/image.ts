import { Router, Request, Response } from 'express'

const router = Router()

router.post('/', async (req: Request, res: Response) => {
  try {
    const { prompt } = req.body
    if (!prompt) return res.status(400).json({ error: 'prompt is required' })

    const key = process.env.FLUX_API_KEY
    if (!key) return res.status(500).json({ error: 'Image key missing — add FLUX_API_KEY to your environment variables' })

    // fal.ai API call
    const response = await fetch('https://fal.run/fal-ai/flux/schnell', {
      method: 'POST',
      headers: {
        Authorization: `Key ${key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        image_size: 'landscape_4_3',
        num_inference_steps: 4,
        num_images: 1,
      }),
    })

    if (!response.ok) {
      const err = await response.json().catch(() => ({}))
      throw new Error(err.detail || err.message || `Image API error: ${response.status}`)
    }

    const data = await response.json()
    const imageUrl = data.images?.[0]?.url || data.image?.url

    if (!imageUrl) throw new Error('No image URL in response')

    res.json({ url: imageUrl, prompt })
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Image generation error' })
  }
})

export default router
