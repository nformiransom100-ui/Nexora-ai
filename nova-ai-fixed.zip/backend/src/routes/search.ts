import { Router, Request, Response } from 'express'
import { chatCompletionText } from '../lib/openrouter'

const router = Router()

function getTavilyKey() {
  const key = process.env.TAVILY_API_KEY
  if (!key) throw new Error('Search key missing — add TAVILY_API_KEY to your environment variables')
  return key
}

async function tavilySearch(query: string, depth: 'basic' | 'advanced' = 'basic') {
  const res = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      api_key: getTavilyKey(),
      query,
      search_depth: depth,
      include_answer: true,
      include_raw_content: false,
      max_results: 6,
    }),
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.message || `Tavily error: ${res.status}`)
  }

  return res.json()
}

// ─── POST /api/search ─────────────────────────────────────────────────────────
router.post('/search', async (req: Request, res: Response) => {
  try {
    const { query } = req.body
    if (!query) return res.status(400).json({ error: 'query is required' })

    const data = await tavilySearch(query)
    const results = data.results || []

    const context = results
      .slice(0, 4)
      .map((r: { title: string; url: string; content: string }) => `[${r.title}](${r.url})\n${r.content}`)
      .join('\n\n')

    const summary = await chatCompletionText([
      { role: 'user', content: `Summarize these search results for the query: "${query}"\n\n${context}` }
    ], 'search')

    res.json({ query, results, summary })
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Search error' })
  }
})

// ─── POST /api/deep-research ──────────────────────────────────────────────────
router.post('/deep-research', async (req: Request, res: Response) => {
  try {
    const { topic } = req.body
    if (!topic) return res.status(400).json({ error: 'topic is required' })

    // Multiple searches for breadth
    const queries = [
      topic,
      `${topic} latest research`,
      `${topic} key findings analysis`,
    ]

    const allResults: unknown[] = []
    for (const q of queries) {
      try {
        const data = await tavilySearch(q, 'advanced')
        allResults.push(...(data.results || []))
      } catch {}
    }

    // Deduplicate by URL
    const seen = new Set<string>()
    const uniqueResults = allResults.filter((r: unknown) => {
      const result = r as { url: string }
      if (seen.has(result.url)) return false
      seen.add(result.url)
      return true
    })

    const context = uniqueResults
      .slice(0, 8)
      .map((r: unknown) => {
        const result = r as { title: string; url: string; content: string }
        return `[${result.title}](${result.url})\n${result.content}`
      })
      .join('\n\n')

    const reportRaw = await chatCompletionText([
      {
        role: 'user',
        content: `You are a research analyst. Write a comprehensive research report on: "${topic}"

Use these sources:
${context}

Format your response as JSON with these exact keys:
{
  "summary": "2-3 sentence overview",
  "keyFindings": ["finding 1", "finding 2", "finding 3", "finding 4", "finding 5"],
  "details": "detailed paragraphs covering the topic thoroughly",
  "finalAnswer": "concise direct answer to the research question"
}`
      }
    ], 'research')

    let report
    try {
      const cleaned = reportRaw.replace(/```json|```/g, '').trim()
      report = JSON.parse(cleaned)
    } catch {
      report = {
        summary: reportRaw.slice(0, 300),
        keyFindings: [],
        details: reportRaw,
        finalAnswer: reportRaw.slice(0, 200),
      }
    }

    res.json({
      topic,
      ...report,
      sources: uniqueResults.slice(0, 8),
    })
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Research error' })
  }
})

export default router
