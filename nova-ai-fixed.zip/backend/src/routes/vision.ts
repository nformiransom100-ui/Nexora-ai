import { Router, Request, Response } from 'express'

const router = Router()

router.post('/', async (req: Request, res: Response) => {
  try {
    const { image, mimeType, prompt = 'Describe this image in detail.' } = req.body

    if (!image) return res.status(400).json({ error: 'image (base64) is required' })

    const key = process.env.OPENROUTER_API_KEY
    if (!key) return res.status(500).json({ error: 'OpenRouter key missing' })

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${key}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://nova-ai.app',
        'X-Title': 'Nova AI',
      },
      body: JSON.stringify({
        model: 'anthropic/claude-3-haiku',
        messages: [
          {
            role: 'user',
            content: [
              { type: 'image_url', image_url: { url: `data:${mimeType || 'image/jpeg'};base64,${image}` } },
              { type: 'text', text: prompt },
            ],
          },
        ],
        max_tokens: 1024,
      }),
    })

    if (!response.ok) {
      const err = await response.json().catch(() => ({}))
      // Graceful fallback
      if (response.status === 400 || response.status === 422) {
        return res.status(200).json({
          content: 'Vision analysis is not available for this image. Please try a different image or describe what you see.',
        })
      }
      throw new Error(err.error?.message || `Vision API error: ${response.status}`)
    }

    const data = await response.json()
    const content = data.choices?.[0]?.message?.content || 'Could not analyze image.'

    res.json({ content })
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Vision error' })
  }
})

export default router
