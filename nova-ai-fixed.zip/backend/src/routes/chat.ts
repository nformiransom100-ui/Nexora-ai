import { Router, Request, Response } from 'express'
import { chatCompletion, chatCompletionText } from '../lib/openrouter'

const router = Router()

router.post('/', async (req: Request, res: Response) => {
  try {
    const { messages, mode = 'chat', context, stream = false } = req.body

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'messages array is required' })
    }

    const finalMessages = context
      ? [{ role: 'system', content: `Context:\n${context}` }, ...messages]
      : messages

    if (stream) {
      const upstream = await chatCompletion(finalMessages, mode, true)

      res.setHeader('Content-Type', 'text/event-stream')
      res.setHeader('Cache-Control', 'no-cache')
      res.setHeader('Connection', 'keep-alive')

      if (!upstream.body) {
        return res.status(500).json({ error: 'No stream body from OpenRouter' })
      }

      // Use getReader() from Web Streams API
      const reader = (upstream.body as any).getReader()
      const decoder = new TextDecoder()

      const pump = async () => {
        try {
          while (true) {
            const { done, value } = await reader.read()
            if (done) { res.end(); break }
            res.write(decoder.decode(value, { stream: true }))
          }
        } catch {
          res.end()
        }
      }

      req.on('close', () => reader.cancel())
      pump()

    } else {
      const content = await chatCompletionText(finalMessages, mode)
      res.json({ content })
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Chat error'
    res.status(500).json({ error: msg })
  }
})

export default router
