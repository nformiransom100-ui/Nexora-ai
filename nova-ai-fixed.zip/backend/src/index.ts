import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import path from 'path'
import chatRouter from './routes/chat'
import searchRouter from './routes/search'
import imageRouter from './routes/image'
import fileRouter from './routes/file'
import visionRouter from './routes/vision'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3001

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({ origin: '*', credentials: true }))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))

// ─── Health ───────────────────────────────────────────────────────────────────
app.get('/api/health', (_, res) => {
  res.json({
    status: 'ok',
    keys: {
      openrouter: !!process.env.OPENROUTER_API_KEY,
      tavily: !!process.env.TAVILY_API_KEY,
      flux: !!process.env.FLUX_API_KEY,
      supabase: !!process.env.SUPABASE_URL,
    },
  })
})

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/chat', chatRouter)
app.use('/api', searchRouter)
app.use('/api/image', imageRouter)
app.use('/api/file', fileRouter)
app.use('/api/vision', visionRouter)

// ─── Serve Frontend (production) ─────────────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  const frontendDist = path.join(__dirname, '../../frontend/dist')
  app.use(express.static(frontendDist))
  app.get('*', (_, res) => res.sendFile(path.join(frontendDist, 'index.html')))
}

// ─── Error Handler ───────────────────────────────────────────────────────────
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[Nova AI Error]', err.message)
  res.status(500).json({ error: err.message || 'Internal server error' })
})

app.listen(PORT, () => {
  console.log(`🚀 Nova AI backend running on http://localhost:${PORT}`)
})

export default app
