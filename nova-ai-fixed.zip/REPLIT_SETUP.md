# Nova AI — Replit Setup Guide

## Step 1 — Import to Replit

1. Open [replit.com](https://replit.com) → **Create Repl**
2. Choose **"Import from GitHub"** (or upload the zip and unzip it)
3. Select **Node.js** as the language

---

## Step 2 — Add Environment Variables

Go to **Tools → Secrets** in the left sidebar. Add these one by one:

### Required for frontend (must start with `VITE_`):
```
VITE_SUPABASE_URL       = https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY  = eyJhbGciOi...
VITE_API_URL            = http://localhost:3001
```

### Required for backend:
```
SUPABASE_URL            = https://xxxx.supabase.co
SUPABASE_ANON_KEY       = eyJhbGciOi...
OPENROUTER_API_KEY      = sk-or-v1-...
TAVILY_API_KEY          = tvly-...
FLUX_API_KEY            = your-fal-ai-key
PORT                    = 3001
NODE_ENV                = development
```

> ⚠️ The app works without API keys — it will show clear error messages per feature.
> The UI and navigation work with zero keys configured.

---

## Step 3 — Install Dependencies

Open the **Shell** tab and run these commands **in order**:

```bash
# 1. Install root deps (concurrently)
npm install

# 2. Install frontend deps
cd frontend
npm install
cd ..

# 3. Install backend deps
cd backend
npm install
cd ..
```

---

## Step 4 — Run the App

### Option A — Run both together (recommended):
```bash
npm run dev
```
This starts:
- **Frontend** on `http://0.0.0.0:5173` (Replit will show a preview)
- **Backend** on `http://0.0.0.0:3001`

### Option B — Run separately (if Option A fails):

**Terminal 1:**
```bash
cd frontend && npm run dev
```

**Terminal 2 (open another Shell tab):**
```bash
cd backend && npm run dev
```

---

## Step 5 — Open the Preview

- Replit will automatically detect port **5173** and show a **Preview** button at the top
- Click **Open in new tab** for the full mobile view
- On mobile: share the Replit URL directly — it works as a PWA

---

## Step 6 — What to Test First

### Test 1: UI loads (no API keys needed)
- Open the preview → you should see "What can I help with?" with 8 quick action cards
- Tap any quick action card
- The chat screen should open

### Test 2: Chat works (needs OPENROUTER_API_KEY)
- Type a message in the input bar and press Send
- You should see the AI reply streaming in
- If the key is missing, you'll see: *"OpenRouter key missing"*

### Test 3: Web search (needs TAVILY_API_KEY)
- Tap the **+** button → **Web Search**
- Type a query and send
- Results + AI summary should appear

### Test 4: Image generation (needs FLUX_API_KEY)
- Tap the **+** button → **Create Image**
- Type: `a futuristic city at night, purple neon`
- Image should generate and appear in chat

### Test 5: Backend health check
```bash
curl http://localhost:3001/api/health
```
Should return:
```json
{
  "status": "ok",
  "keys": {
    "openrouter": true,
    "tavily": true,
    "flux": true,
    "supabase": true
  }
}
```

---

## Build for Production

```bash
# Type-check + build frontend
cd frontend && npm run build

# Or skip type-check (faster, still works):
cd frontend && npm run build:force
```

Built files go to `frontend/dist/`. The backend serves them automatically when `NODE_ENV=production`.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Module not found: lucide-react` | Run `cd frontend && npm install` |
| `Cannot find module 'express'` | Run `cd backend && npm install` |
| Port 5173 not showing | Check `.replit` file exists, or run `cd frontend && npm run dev` manually |
| `VITE_*` vars not working | They must be added to Replit Secrets with the `VITE_` prefix exactly |
| Backend not starting | Check Secrets has `PORT=3001` and `NODE_ENV=development` |
| White screen | Open browser DevTools → Console and share the error |

---

## File Structure Reference

```
nova-ai/
├── .replit              ← Replit run config
├── package.json         ← Root: starts both servers
├── frontend/
│   ├── src/
│   │   ├── components/  ← TopBar, Sidebar, InputBar, MessageBubble, etc.
│   │   ├── pages/       ← HomeScreen, ChatScreen
│   │   ├── hooks/       ← useChat
│   │   ├── lib/         ← api.ts, context.tsx, utils.ts, supabase.ts
│   │   └── types/       ← TypeScript types
│   └── package.json
├── backend/
│   ├── src/
│   │   ├── routes/      ← chat, search, image, file, vision
│   │   └── lib/         ← openrouter.ts
│   └── package.json
└── supabase/
    └── schema.sql       ← Run this in Supabase SQL Editor
```
