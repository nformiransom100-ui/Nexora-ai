/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        nova: {
          bg:       '#0a0a0a',
          surface:  '#141414',
          card:     '#1c1c1c',
          border:   '#2a2a2a',
          muted:    '#3a3a3a',
          text:     '#e8e8e8',
          subtext:  '#888888',
          accent:   '#7c6af7',
          'accent-hover': '#6a58e5',
          'accent-dim':   '#7c6af720',
          success:  '#22c55e',
          warning:  '#f59e0b',
          error:    '#ef4444',
        },
      },
      fontFamily: {
        sans: ['Inter var', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      borderRadius: {
        'xl':  '12px',
        '2xl': '16px',
        '3xl': '24px',
      },
      animation: {
        'fade-in':    'fadeIn 0.2s ease-out',
        'slide-up':   'slideUp 0.3s ease-out',
        'slide-left': 'slideLeft 0.3s ease-out',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'orb':        'orbFloat 4s ease-in-out infinite',
        'typing':     'typing 1.2s steps(3) infinite',
      },
      keyframes: {
        fadeIn:    { from: { opacity: '0' }, to: { opacity: '1' } },
        slideUp:   { from: { opacity: '0', transform: 'translateY(12px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        slideLeft: { from: { opacity: '0', transform: 'translateX(-12px)' }, to: { opacity: '1', transform: 'translateX(0)' } },
        orbFloat:  {
          '0%, 100%': { transform: 'scale(1)', filter: 'blur(0px)' },
          '50%':      { transform: 'scale(1.08)', filter: 'blur(1px)' },
        },
        typing: {
          '0%':   { content: '"."' },
          '33%':  { content: '".."' },
          '66%':  { content: '"..."' },
          '100%': { content: '"."' },
        },
      },
    },
  },
  plugins: [],
}
