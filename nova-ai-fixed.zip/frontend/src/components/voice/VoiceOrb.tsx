import { useState, useCallback, useRef } from 'react'
import { X, MicOff, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'

interface VoiceOrbProps {
  open: boolean
  onClose: () => void
  onTranscript: (text: string) => void
}

type OrbState = 'idle' | 'listening' | 'thinking'

export function VoiceOrb({ open, onClose, onTranscript }: VoiceOrbProps) {
  const [orbState, setOrbState] = useState<OrbState>('idle')
  const [displayText, setDisplayText] = useState('')
  const [statusText, setStatusText] = useState('Tap to speak')
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  // Ref avoids stale closure inside recognition.onend
  const transcriptRef = useRef('')

  const startListening = useCallback(() => {
    const SR =
      (window as unknown as { SpeechRecognition?: typeof window.SpeechRecognition }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: typeof window.SpeechRecognition }).webkitSpeechRecognition

    if (!SR) {
      setStatusText('Speech not supported in this browser')
      return
    }

    if (orbState === 'listening') {
      recognitionRef.current?.stop()
      return
    }

    const recognition = new SR()
    recognition.lang = 'en-US'
    recognition.interimResults = true
    recognition.maxAlternatives = 1
    transcriptRef.current = ''

    recognition.onstart = () => {
      setOrbState('listening')
      setStatusText('Listening…')
      setDisplayText('')
      transcriptRef.current = ''
    }

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interim = ''
      let final = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          final += event.results[i][0].transcript
        } else {
          interim += event.results[i][0].transcript
        }
      }
      const text = final || interim
      transcriptRef.current = text
      setDisplayText(text)
    }

    recognition.onend = () => {
      const finalText = transcriptRef.current.trim()
      if (finalText) {
        setOrbState('thinking')
        setStatusText('Got it!')
        setTimeout(() => {
          onTranscript(finalText)
          onClose()
          setOrbState('idle')
          setStatusText('Tap to speak')
          setDisplayText('')
          transcriptRef.current = ''
        }, 500)
      } else {
        setOrbState('idle')
        setStatusText('Tap to speak')
      }
    }

    recognition.onerror = () => {
      setOrbState('idle')
      setStatusText('Tap to speak')
    }

    recognitionRef.current = recognition
    recognition.start()
  }, [orbState, onTranscript, onClose])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-nova-bg/98 backdrop-blur-sm animate-fade-in">
      <button
        onClick={() => { recognitionRef.current?.stop(); onClose() }}
        className="absolute top-14 right-5 w-10 h-10 flex items-center justify-center rounded-full bg-nova-card border border-nova-border active:scale-95 transition-all"
      >
        <X size={18} className="text-nova-subtext" />
      </button>

      <div className="flex items-center gap-2 mb-16">
        <Sparkles size={16} className="text-nova-accent" />
        <span className="text-nova-text font-medium">Nova Voice</span>
      </div>

      <button
        onClick={startListening}
        className="relative mb-12 focus:outline-none"
        aria-label="Start voice input"
      >
        <div className={cn(
          'absolute inset-0 rounded-full border-2 border-nova-accent/20 scale-125 transition-opacity',
          orbState === 'listening' ? 'animate-ping opacity-40' : 'opacity-0'
        )} />
        <div className={cn(
          'absolute inset-0 rounded-full border border-nova-accent/10 scale-150 transition-opacity',
          orbState === 'listening' ? 'animate-ping opacity-20' : 'opacity-0'
        )} />

        <div className={cn(
          'relative w-28 h-28 rounded-full flex items-center justify-center transition-all duration-300',
          orbState === 'idle' && 'bg-nova-card border-2 border-nova-border',
          orbState === 'listening' && 'bg-nova-accent shadow-[0_0_60px_rgba(124,106,247,0.5)] scale-110',
          orbState === 'thinking' && 'bg-nova-accent/80 animate-pulse',
        )}>
          {orbState === 'idle'
            ? <MicOff size={32} className="text-nova-subtext" />
            : <Sparkles size={32} className="text-white" />
          }
        </div>
      </button>

      <div className="px-8 text-center min-h-[60px]">
        {displayText ? (
          <p className="text-nova-text text-base leading-relaxed">{displayText}</p>
        ) : (
          <p className="text-nova-subtext text-sm">{statusText}</p>
        )}
      </div>
    </div>
  )
}
