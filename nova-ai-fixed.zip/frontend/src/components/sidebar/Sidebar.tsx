import { useEffect, useRef } from 'react'
import {
  X, Plus, MessageSquare, Search, FolderOpen,
  Image, Wrench, Settings, User, Sparkles, ChevronRight
} from 'lucide-react'
import { useApp } from '@/lib/context'
import { cn, truncate, formatDate } from '@/lib/utils'
import { Chat } from '@/types'

interface SidebarProps {
  onNewChat: () => void
  onSelectChat: (chat: Chat) => void
}

export function Sidebar({ onNewChat, onSelectChat }: SidebarProps) {
  const { sidebarOpen, setSidebarOpen, chats, currentChat } = useApp()
  const overlayRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (sidebarOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => { document.body.style.overflow = '' }
  }, [sidebarOpen])

  const navItems = [
    { icon: Image, label: 'Images', onClick: () => {} },
    { icon: Wrench, label: 'Tools', onClick: () => {} },
    { icon: Settings, label: 'Settings', onClick: () => {} },
    { icon: User, label: 'Account', onClick: () => {} },
  ]

  return (
    <>
      {/* Overlay */}
      <div
        ref={overlayRef}
        onClick={() => setSidebarOpen(false)}
        className={cn(
          'fixed inset-0 bg-black/60 z-40 transition-opacity duration-300',
          sidebarOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        )}
      />

      {/* Drawer */}
      <aside
        className={cn(
          'fixed left-0 top-0 bottom-0 w-[280px] bg-nova-surface border-r border-nova-border z-50',
          'flex flex-col transition-transform duration-300 ease-out safe-top',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-nova-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-nova-accent flex items-center justify-center">
              <Sparkles size={14} className="text-white" />
            </div>
            <span className="font-semibold text-nova-text">Nova AI</span>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-nova-card active:scale-95 transition-all"
          >
            <X size={16} className="text-nova-subtext" />
          </button>
        </div>

        {/* New Chat */}
        <div className="px-3 py-3 border-b border-nova-border">
          <button
            onClick={() => { onNewChat(); setSidebarOpen(false) }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl bg-nova-accent/10 hover:bg-nova-accent/20 active:scale-[0.98] transition-all"
          >
            <Plus size={16} className="text-nova-accent" />
            <span className="text-sm font-medium text-nova-accent">New Chat</span>
          </button>
        </div>

        {/* Search */}
        <div className="px-3 py-2">
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-nova-card border border-nova-border">
            <Search size={14} className="text-nova-subtext flex-shrink-0" />
            <input
              type="text"
              placeholder="Search chats..."
              className="flex-1 bg-transparent text-sm text-nova-text placeholder:text-nova-subtext focus:outline-none"
            />
          </div>
        </div>

        {/* Recent Chats */}
        <div className="flex-1 overflow-y-auto px-3 py-2">
          {chats.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare size={24} className="text-nova-muted mx-auto mb-2" />
              <p className="text-xs text-nova-subtext">No chats yet</p>
            </div>
          ) : (
            <>
              <p className="text-[11px] font-medium text-nova-subtext uppercase tracking-wider px-2 mb-2">Recent</p>
              <div className="space-y-0.5">
                {chats.slice(0, 20).map(chat => (
                  <button
                    key={chat.id}
                    onClick={() => { onSelectChat(chat); setSidebarOpen(false) }}
                    className={cn(
                      'w-full flex items-start gap-2.5 px-3 py-2.5 rounded-xl text-left',
                      'hover:bg-nova-card active:scale-[0.98] transition-all',
                      currentChat?.id === chat.id && 'bg-nova-card border border-nova-border'
                    )}
                  >
                    <MessageSquare size={14} className="text-nova-subtext mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-nova-text truncate">{truncate(chat.title, 35)}</p>
                      <p className="text-[11px] text-nova-subtext mt-0.5">{formatDate(chat.updated_at)}</p>
                    </div>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Nav Items */}
        <div className="border-t border-nova-border px-3 py-2 space-y-0.5">
          {navItems.map(item => (
            <button
              key={item.label}
              onClick={item.onClick}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-nova-card active:scale-[0.98] transition-all"
            >
              <item.icon size={16} className="text-nova-subtext" />
              <span className="text-sm text-nova-subtext flex-1 text-left">{item.label}</span>
              <ChevronRight size={13} className="text-nova-muted" />
            </button>
          ))}
        </div>
      </aside>
    </>
  )
}
