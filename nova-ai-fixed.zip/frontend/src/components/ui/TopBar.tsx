import { Menu, Settings, Sparkles } from 'lucide-react'
import { useApp } from '@/lib/context'

interface TopBarProps {
  title?: string
}

export function TopBar({ title = 'Nova AI' }: TopBarProps) {
  const { setSidebarOpen } = useApp()

  return (
    <div className="flex items-center justify-between px-4 py-3 safe-top bg-nova-bg/95 backdrop-blur-sm border-b border-nova-border/50 sticky top-0 z-30">
      <button
        onClick={() => setSidebarOpen(true)}
        className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-nova-card active:scale-95 transition-all"
        aria-label="Open menu"
      >
        <Menu size={20} className="text-nova-subtext" />
      </button>

      <div className="flex items-center gap-1.5">
        <div className="w-6 h-6 rounded-lg bg-nova-accent flex items-center justify-center">
          <Sparkles size={13} className="text-white" />
        </div>
        <span className="font-semibold text-nova-text tracking-tight text-[15px]">{title}</span>
      </div>

      <button
        onClick={() => {/* settings nav */}}
        className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-nova-card active:scale-95 transition-all"
        aria-label="Settings"
      >
        <div className="w-7 h-7 rounded-full bg-nova-muted flex items-center justify-center">
          <Settings size={14} className="text-nova-subtext" />
        </div>
      </button>
    </div>
  )
}
