import { AlertCircle, X } from 'lucide-react'

interface ErrorBannerProps {
  error: string
  onDismiss: () => void
}

export function ErrorBanner({ error, onDismiss }: ErrorBannerProps) {
  return (
    <div className="mx-4 mb-2 flex items-start gap-3 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 animate-fade-in">
      <AlertCircle size={15} className="text-red-400 flex-shrink-0 mt-0.5" />
      <p className="flex-1 text-sm text-red-300 leading-relaxed">{error}</p>
      <button
        onClick={onDismiss}
        className="text-red-400 hover:text-red-300 active:scale-95 transition-all"
      >
        <X size={14} />
      </button>
    </div>
  )
}
