import {
  Sparkles, PenLine, BarChart2, Code2,
  Lightbulb, MessageCircle, AlignLeft, Languages
} from 'lucide-react'
import { AIMode } from '@/types'
import { cn } from '@/lib/utils'

interface QuickAction {
  mode: AIMode
  icon: React.ElementType
  label: string
  prompt: string
  gradient: string
}

const QUICK_ACTIONS: QuickAction[] = [
  {
    mode: 'image',
    icon: Sparkles,
    label: 'Create image',
    prompt: 'Create an image of ',
    gradient: 'from-violet-500/20 to-purple-500/10',
  },
  {
    mode: 'write',
    icon: PenLine,
    label: 'Help me write',
    prompt: 'Help me write ',
    gradient: 'from-blue-500/20 to-cyan-500/10',
  },
  {
    mode: 'analyze',
    icon: BarChart2,
    label: 'Analyze data',
    prompt: 'Analyze this data: ',
    gradient: 'from-emerald-500/20 to-green-500/10',
  },
  {
    mode: 'code',
    icon: Code2,
    label: 'Code',
    prompt: 'Write code to ',
    gradient: 'from-orange-500/20 to-amber-500/10',
  },
  {
    mode: 'brainstorm',
    icon: Lightbulb,
    label: 'Brainstorm',
    prompt: 'Brainstorm ideas for ',
    gradient: 'from-yellow-500/20 to-orange-500/10',
  },
  {
    mode: 'advice',
    icon: MessageCircle,
    label: 'Get advice',
    prompt: 'Give me advice on ',
    gradient: 'from-pink-500/20 to-rose-500/10',
  },
  {
    mode: 'summarize',
    icon: AlignLeft,
    label: 'Summarize',
    prompt: 'Summarize: ',
    gradient: 'from-teal-500/20 to-cyan-500/10',
  },
  {
    mode: 'translate',
    icon: Languages,
    label: 'Translate',
    prompt: 'Translate to ',
    gradient: 'from-indigo-500/20 to-blue-500/10',
  },
]

interface QuickActionsProps {
  onSelect: (action: QuickAction) => void
}

export function QuickActions({ onSelect }: QuickActionsProps) {
  return (
    <div className="px-4">
      <div className="grid grid-cols-2 gap-2.5">
        {QUICK_ACTIONS.map((action, i) => (
          <button
            key={action.mode}
            onClick={() => onSelect(action)}
            className={cn(
              'flex items-center gap-3 px-4 py-3.5 rounded-2xl border border-nova-border',
              `bg-gradient-to-br ${action.gradient}`,
              'hover:border-nova-muted active:scale-[0.97] transition-all text-left',
              'animate-fade-in'
            )}
            style={{ animationDelay: `${i * 40}ms` }}
          >
            <action.icon size={16} className="text-nova-text flex-shrink-0" />
            <span className="text-sm font-medium text-nova-text">{action.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

export type { QuickAction }
