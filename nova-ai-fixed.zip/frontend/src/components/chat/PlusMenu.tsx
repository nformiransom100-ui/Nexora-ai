import { useEffect, useRef } from 'react'
import { Camera, Image, FileText, Sparkles, Search, Globe, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { PlusMenuItem } from '@/types'

interface PlusMenuProps {
  open: boolean
  onClose: () => void
  onSelect: (item: PlusMenuItem) => void
}

const MENU_ITEMS: { id: PlusMenuItem; icon: React.ElementType; label: string; color: string }[] = [
  { id: 'camera',   icon: Camera,   label: 'Camera',        color: 'text-blue-400' },
  { id: 'photos',   icon: Image,    label: 'Photos',        color: 'text-green-400' },
  { id: 'files',    icon: FileText, label: 'Files',         color: 'text-orange-400' },
  { id: 'image',    icon: Sparkles, label: 'Create Image',  color: 'text-nova-accent' },
  { id: 'research', icon: Search,   label: 'Deep Research', color: 'text-yellow-400' },
  { id: 'search',   icon: Globe,    label: 'Web Search',    color: 'text-cyan-400' },
]

export function PlusMenu({ open, onClose, onSelect }: PlusMenuProps) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        onClose()
      }
    }
    if (open) document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [open, onClose])

  if (!open) return null

  return (
    <div
      ref={ref}
      className="absolute bottom-full left-0 mb-2 w-56 bg-nova-surface border border-nova-border rounded-2xl shadow-2xl shadow-black/50 overflow-hidden animate-slide-up z-20"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-nova-border">
        <span className="text-xs font-medium text-nova-subtext uppercase tracking-wider">Attach</span>
        <button onClick={onClose} className="w-5 h-5 flex items-center justify-center rounded-md hover:bg-nova-card transition-colors">
          <X size={12} className="text-nova-subtext" />
        </button>
      </div>
      <div className="p-1.5">
        {MENU_ITEMS.map(item => (
          <button
            key={item.id}
            onClick={() => { onSelect(item.id); onClose() }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-nova-card active:scale-[0.98] transition-all text-left"
          >
            <item.icon size={16} className={item.color} />
            <span className="text-sm text-nova-text">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
