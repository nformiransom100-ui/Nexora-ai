import { useState, memo } from 'react'
import { Copy, Check, RefreshCw, User, Sparkles } from 'lucide-react'
import { Message } from '@/types'

// Simple markdown renderer without external deps
function renderMarkdown(content: string): string {
  return content
    // Code blocks (must come before inline code)
    .replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) =>
      `<pre data-lang="${lang}"><code>${escapeHtml(code.trim())}</code></pre>`
    )
    // Inline code
    .replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>')
    // Bold
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    // Headers
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^# (.+)$/gm, '<h1>$1</h1>')
    // Bullet lists
    .replace(/^[•\-\*] (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>')
    // Numbered lists
    .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
    // Horizontal rule
    .replace(/^---$/gm, '<hr />')
    // Paragraphs (double newlines)
    .split('\n\n')
    .map(p => p.trim())
    .filter(Boolean)
    .map(p => p.startsWith('<') ? p : `<p>${p.replace(/\n/g, '<br />')}</p>`)
    .join('\n')
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

// Code block with copy button
function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false)

  const copy = () => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div className="rounded-xl overflow-hidden border border-nova-border my-3 bg-[#0d0d0d]">
      <div className="flex items-center justify-between px-4 py-2 border-b border-nova-border bg-nova-surface/50">
        <span className="text-[11px] font-mono text-nova-subtext">{lang || 'code'}</span>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 text-[11px] text-nova-subtext hover:text-nova-text transition-colors active:scale-95"
        >
          {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
          <span>{copied ? 'Copied' : 'Copy'}</span>
        </button>
      </div>
      <pre className="p-4 overflow-x-auto text-[13px] leading-relaxed font-mono text-nova-text">
        <code>{code}</code>
      </pre>
    </div>
  )
}

// Parse and render mixed content (text + code blocks)
function MessageContent({ content }: { content: string }) {
  const parts: Array<{ type: 'text' | 'code'; content: string; lang?: string }> = []
  const codeBlockRegex = /```(\w*)\n?([\s\S]*?)```/g
  let lastIndex = 0
  let match

  while ((match = codeBlockRegex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      parts.push({ type: 'text', content: content.slice(lastIndex, match.index) })
    }
    parts.push({ type: 'code', content: match[2].trim(), lang: match[1] })
    lastIndex = match.index + match[0].length
  }

  if (lastIndex < content.length) {
    parts.push({ type: 'text', content: content.slice(lastIndex) })
  }

  if (parts.length === 0) {
    parts.push({ type: 'text', content })
  }

  return (
    <div className="space-y-1">
      {parts.map((part, i) => {
        if (part.type === 'code') {
          return <CodeBlock key={i} code={part.content} lang={part.lang || ''} />
        }
        return (
          <div
            key={i}
            className="nova-markdown"
            dangerouslySetInnerHTML={{
              __html: renderMarkdown(part.content)
            }}
          />
        )
      })}
    </div>
  )
}

interface MessageBubbleProps {
  message: Message
  isLast?: boolean
  onRegenerate?: () => void
  isLoading?: boolean
}

export const MessageBubble = memo(function MessageBubble({
  message,
  isLast,
  onRegenerate,
  isLoading,
}: MessageBubbleProps) {
  const [copied, setCopied] = useState(false)
  const isUser = message.role === 'user'
  const isAssistant = message.role === 'assistant'
  const isEmpty = !message.content && isAssistant

  const copy = () => {
    navigator.clipboard.writeText(message.content).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div className={cn('flex gap-3 px-4 py-3 animate-fade-in', isUser && 'flex-row-reverse')}>
      {/* Avatar */}
      <div className={cn(
        'w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5',
        isUser ? 'bg-nova-muted' : 'bg-nova-accent'
      )}>
        {isUser
          ? <User size={14} className="text-nova-subtext" />
          : <Sparkles size={13} className="text-white" />
        }
      </div>

      {/* Content */}
      <div className={cn('flex-1 min-w-0', isUser && 'flex flex-col items-end')}>
        <div className={cn(
          'rounded-2xl px-4 py-3 max-w-[85%] text-sm leading-relaxed',
          isUser
            ? 'bg-nova-accent text-white rounded-tr-sm'
            : 'bg-nova-card border border-nova-border text-nova-text rounded-tl-sm'
        )}>
          {isEmpty ? (
            <TypingIndicator />
          ) : (
            isUser
              ? <p className="whitespace-pre-wrap">{message.content}</p>
              : <MessageContent content={message.content} />
          )}
        </div>

        {/* Action buttons (assistant only) */}
        {isAssistant && !isEmpty && (
          <div className="flex items-center gap-1 mt-1.5 ml-1">
            <button
              onClick={copy}
              className="flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] text-nova-subtext hover:text-nova-text hover:bg-nova-card active:scale-95 transition-all"
            >
              {copied ? <Check size={11} className="text-green-400" /> : <Copy size={11} />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            {isLast && onRegenerate && !isLoading && (
              <button
                onClick={onRegenerate}
                className="flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] text-nova-subtext hover:text-nova-text hover:bg-nova-card active:scale-95 transition-all"
              >
                <RefreshCw size={11} />
                <span>Retry</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  )
})

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1 py-1">
      <span className="w-1.5 h-1.5 rounded-full bg-nova-subtext animate-bounce" style={{ animationDelay: '0ms' }} />
      <span className="w-1.5 h-1.5 rounded-full bg-nova-subtext animate-bounce" style={{ animationDelay: '150ms' }} />
      <span className="w-1.5 h-1.5 rounded-full bg-nova-subtext animate-bounce" style={{ animationDelay: '300ms' }} />
    </div>
  )
}
