import { useState, useRef, useCallback, KeyboardEvent } from 'react'
import { Plus, Mic, Send, Square, Radio } from 'lucide-react'
import { cn } from '@/lib/utils'
import { PlusMenu } from './PlusMenu'
import { PlusMenuItem } from '@/types'

interface InputBarProps {
  onSend: (text: string) => void
  onPlusSelect: (item: PlusMenuItem) => void
  onVoiceOrb: () => void
  isLoading: boolean
  onStop: () => void
  disabled?: boolean
  placeholder?: string
}

export function InputBar({
  onSend,
  onPlusSelect,
  onVoiceOrb,
  isLoading,
  onStop,
  disabled = false,
  placeholder = 'Ask Nova AI',
}: InputBarProps) {
  const [text, setText] = useState('')
  const [plusOpen, setPlusOpen] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  const handleSend = useCallback(() => {
    const trimmed = text.trim()
    if (!trimmed || isLoading) return
    onSend(trimmed)
    setText('')
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
    }
  }, [text, isLoading, onSend])

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleInput = () => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = Math.min(el.scrollHeight, 120) + 'px'
  }

  const startVoice = useCallback(() => {
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition?: typeof window.SpeechRecognition; webkitSpeechRecognition?: typeof window.SpeechRecognition }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: typeof window.SpeechRecognition }).webkitSpeechRecognition

    if (!SpeechRecognition) {
      alert('Speech recognition not supported in this browser.')
      return
    }

    if (isListening) {
      recognitionRef.current?.stop()
      setIsListening(false)
      return
    }

    const recognition = new SpeechRecognition()
    recognition.lang = 'en-US'
    recognition.interimResults = false
    recognition.maxAlternatives = 1

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript
      setText(prev => prev ? prev + ' ' + transcript : transcript)
    }

    recognition.onend = () => setIsListening(false)
    recognition.onerror = () => setIsListening(false)

    recognitionRef.current = recognition
    recognition.start()
    setIsListening(true)
  }, [isListening])

  const canSend = text.trim().length > 0 && !disabled

  return (
    <div className="relative px-3 pb-3 pt-2 safe-bottom bg-nova-bg border-t border-nova-border/50">
      {/* Plus menu */}
      <div className="relative">
        <PlusMenu
          open={plusOpen}
          onClose={() => setPlusOpen(false)}
          onSelect={onPlusSelect}
        />
      </div>

      <div className="flex items-end gap-2">
        {/* Plus button */}
        <button
          onClick={() => setPlusOpen(v => !v)}
          className={cn(
            'w-10 h-10 flex-shrink-0 flex items-center justify-center rounded-xl transition-all active:scale-95',
            plusOpen
              ? 'bg-nova-accent text-white'
              : 'bg-nova-card border border-nova-border text-nova-subtext hover:text-nova-text hover:border-nova-muted'
          )}
          aria-label="Attach"
        >
          <Plus size={18} className={cn('transition-transform', plusOpen && 'rotate-45')} />
        </button>

        {/* Text area */}
        <div className="flex-1 flex items-end bg-nova-card border border-nova-border rounded-2xl overflow-hidden focus-within:border-nova-muted transition-colors">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={e => setText(e.target.value)}
            onInput={handleInput}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            rows={1}
            disabled={disabled}
            className="flex-1 bg-transparent px-4 py-3 text-sm text-nova-text placeholder:text-nova-subtext focus:outline-none resize-none max-h-[120px] leading-relaxed"
          />
        </div>

        {/* Right buttons */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {/* Mic */}
          <button
            onClick={startVoice}
            className={cn(
              'w-10 h-10 flex items-center justify-center rounded-xl transition-all active:scale-95',
              isListening
                ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                : 'bg-nova-card border border-nova-border text-nova-subtext hover:text-nova-text hover:border-nova-muted'
            )}
            aria-label="Voice input"
          >
            <Mic size={16} className={cn(isListening && 'animate-pulse')} />
          </button>

          {/* Voice orb / Send */}
          {isLoading ? (
            <button
              onClick={onStop}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-nova-accent active:scale-95 transition-all"
              aria-label="Stop generation"
            >
              <Square size={14} className="text-white fill-white" />
            </button>
          ) : canSend ? (
            <button
              onClick={handleSend}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-nova-accent hover:bg-nova-accent-hover active:scale-95 transition-all"
              aria-label="Send"
            >
              <Send size={15} className="text-white" />
            </button>
          ) : (
            <button
              onClick={onVoiceOrb}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-nova-card border border-nova-border text-nova-subtext hover:text-nova-accent hover:border-nova-accent/40 active:scale-95 transition-all"
              aria-label="Voice conversation"
            >
              <Radio size={16} />
            </button>
          )}
        </div>
      </div>

      <p className="text-center text-[10px] text-nova-muted mt-2">
        Nova AI can make mistakes. Verify important info.
      </p>
    </div>
  )
}
