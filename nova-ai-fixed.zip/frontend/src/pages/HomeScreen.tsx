import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Sparkles } from 'lucide-react'
import { TopBar } from '@/components/ui/TopBar'
import { Sidebar } from '@/components/sidebar/Sidebar'
import { InputBar } from '@/components/chat/InputBar'
import { QuickActions, QuickAction } from '@/components/chat/QuickActions'
import { VoiceOrb } from '@/components/voice/VoiceOrb'
import { useApp } from '@/lib/context'
import { nanoid } from '@/lib/utils'
import { Chat, PlusMenuItem } from '@/types'

export default function HomeScreen() {
  const navigate = useNavigate()
  const { user, setChats, setCurrentChat, setCurrentMode } = useApp()
  const [voiceOrbOpen, setVoiceOrbOpen] = useState(false)

  function createNewChat(initialMessage?: string, mode = 'chat'): Chat {
    const chat: Chat = {
      id: nanoid(),
      user_id: user.id,
      title: initialMessage ? initialMessage.slice(0, 40) : 'New Chat',
      mode: mode as Chat['mode'],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    setChats(prev => [chat, ...prev])
    setCurrentChat(chat)
    return chat
  }

  function handleSend(text: string) {
    const chat = createNewChat(text)
    navigate(`/chat/${chat.id}?init=${encodeURIComponent(text)}`)
  }

  function handleQuickAction(action: QuickAction) {
    setCurrentMode(action.mode)
    const chat = createNewChat(`${action.label} — new chat`)
    navigate(`/chat/${chat.id}?mode=${action.mode}&prompt=${encodeURIComponent(action.prompt)}`)
  }

  function handlePlusSelect(item: PlusMenuItem) {
    const modeMap: Partial<Record<PlusMenuItem, string>> = {
      search: 'search',
      research: 'research',
      image: 'image',
    }
    const mode = modeMap[item]
    if (mode) {
      setCurrentMode(mode as Chat['mode'])
      const chat = createNewChat()
      navigate(`/chat/${chat.id}?mode=${mode}`)
    } else {
      const chat = createNewChat()
      navigate(`/chat/${chat.id}?attach=${item}`)
    }
  }

  return (
    <div className="flex flex-col h-[100dvh] bg-nova-bg overflow-hidden">
      <TopBar />

      <Sidebar
        onNewChat={() => {}}
        onSelectChat={(chat) => {
          setCurrentChat(chat)
          navigate(`/chat/${chat.id}`)
        }}
      />

      <div className="flex-1 overflow-y-auto">
        {/* Hero */}
        <div className="flex flex-col items-center justify-center px-6 pt-16 pb-8">
          <div className="w-16 h-16 rounded-3xl bg-nova-accent flex items-center justify-center mb-6 shadow-[0_0_40px_rgba(124,106,247,0.3)] animate-orb">
            <Sparkles size={28} className="text-white" />
          </div>
          <h1 className="text-2xl font-semibold text-nova-text text-center leading-tight animate-fade-in">
            What can I help with?
          </h1>
          <p className="text-nova-subtext text-sm mt-2 text-center animate-fade-in">
            Ask anything or pick a mode below
          </p>
        </div>

        <QuickActions onSelect={handleQuickAction} />
        <div className="h-6" />
      </div>

      <InputBar
        onSend={handleSend}
        onPlusSelect={handlePlusSelect}
        onVoiceOrb={() => setVoiceOrbOpen(true)}
        isLoading={false}
        onStop={() => {}}
      />

      <VoiceOrb
        open={voiceOrbOpen}
        onClose={() => setVoiceOrbOpen(false)}
        onTranscript={handleSend}
      />
    </div>
  )
}
