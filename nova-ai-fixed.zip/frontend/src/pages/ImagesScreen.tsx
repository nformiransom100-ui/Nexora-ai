export default function ImagesScreen() {
  return <div className="flex items-center justify-center h-screen bg-nova-bg text-nova-subtext">ImagesScreen coming soon…</div>
}
