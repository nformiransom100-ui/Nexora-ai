export default function SettingsScreen() {
  return <div className="flex items-center justify-center h-screen bg-nova-bg text-nova-subtext">SettingsScreen coming soon…</div>
}
