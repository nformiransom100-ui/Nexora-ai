import { useEffect, useRef, useState, useCallback } from 'react'
import { useParams, useSearchParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, MoreHorizontal, Trash2, Edit2 } from 'lucide-react'
import { Sidebar } from '@/components/sidebar/Sidebar'
import { MessageBubble } from '@/components/chat/MessageBubble'
import { InputBar } from '@/components/chat/InputBar'
import { ErrorBanner } from '@/components/ui/ErrorBanner'
import { VoiceOrb } from '@/components/voice/VoiceOrb'
import { useApp } from '@/lib/context'
import { useChat } from '@/hooks/useChat'
import { nanoid } from '@/lib/utils'
import { AIMode, Chat, PlusMenuItem } from '@/types'

export default function ChatScreen() {
  const { chatId } = useParams<{ chatId: string }>()
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const { user, currentChat, setCurrentChat, chats, setChats, currentMode, setCurrentMode } = useApp()
  const [voiceOrbOpen, setVoiceOrbOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const initSentRef = useRef(false)

  // Resolve or create the chat
  const resolvedChatId = chatId || nanoid()

  const mode = (searchParams.get('mode') as AIMode) || currentMode || 'chat'

  const { messages, isLoading, error, setError, sendMessage, regenerate, stopGeneration } = useChat({
    chatId: resolvedChatId,
    mode,
    onSave: () => {},
  })

  // Set mode from URL
  useEffect(() => {
    if (searchParams.get('mode')) {
      setCurrentMode(searchParams.get('mode') as AIMode)
    }
  }, [searchParams, setCurrentMode])

  // Ensure chat exists in list
  useEffect(() => {
    if (!chatId) return
    const exists = chats.find(c => c.id === chatId)
    if (!exists) {
      const newChat: Chat = {
        id: chatId,
        user_id: user.id,
        title: 'New Chat',
        mode,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }
      setChats(prev => [newChat, ...prev])
      setCurrentChat(newChat)
    } else {
      setCurrentChat(exists)
    }
  }, [chatId]) // eslint-disable-line react-hooks/exhaustive-deps

  // Send initial message from URL param (once)
  useEffect(() => {
    if (initSentRef.current) return
    const init = searchParams.get('init')
    if (init) {
      initSentRef.current = true
      sendMessage(decodeURIComponent(init))
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Update chat title on first message
  useEffect(() => {
    if (messages.length === 1 && messages[0].role === 'user') {
      const title = messages[0].content.slice(0, 40)
      setChats(prev => prev.map(c => c.id === resolvedChatId ? { ...c, title } : c))
    }
  }, [messages, resolvedChatId, setChats])

  const handlePlusSelect = useCallback((_item: PlusMenuItem) => {
    // In a real app this would open file picker / camera
    // For now just show it would be handled
  }, [])

  const handleDelete = () => {
    setChats(prev => prev.filter(c => c.id !== resolvedChatId))
    navigate('/')
  }

  const chatTitle = currentChat?.title || chats.find(c => c.id === resolvedChatId)?.title || 'Chat'

  return (
    <div className="flex flex-col h-[100dvh] bg-nova-bg overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-3 safe-top bg-nova-bg/95 backdrop-blur-sm border-b border-nova-border/50 sticky top-0 z-30">
        <button
          onClick={() => navigate('/')}
          className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-nova-card active:scale-95 transition-all"
        >
          <ArrowLeft size={20} className="text-nova-subtext" />
        </button>

        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-nova-text truncate">{chatTitle}</p>
          {mode !== 'chat' && (
            <p className="text-[11px] text-nova-accent capitalize">{mode} mode</p>
          )}
        </div>

        <div className="relative">
          <button
            onClick={() => setMenuOpen(v => !v)}
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-nova-card active:scale-95 transition-all"
          >
            <MoreHorizontal size={18} className="text-nova-subtext" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-full mt-1 w-44 bg-nova-surface border border-nova-border rounded-xl shadow-2xl shadow-black/50 z-20 overflow-hidden animate-fade-in">
              <button
                onClick={() => setMenuOpen(false)}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-nova-card text-left transition-colors"
              >
                <Edit2 size={14} className="text-nova-subtext" />
                <span className="text-sm text-nova-text">Rename</span>
              </button>
              <button
                onClick={handleDelete}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-nova-card text-left transition-colors border-t border-nova-border"
              >
                <Trash2 size={14} className="text-red-400" />
                <span className="text-sm text-red-400">Delete chat</span>
              </button>
            </div>
          )}
        </div>
      </div>

      <Sidebar
        onNewChat={() => navigate('/')}
        onSelectChat={(chat) => {
          setCurrentChat(chat)
          navigate(`/chat/${chat.id}`)
        }}
      />

      {/* Messages */}
      <div className="flex-1 overflow-y-auto py-2" onClick={() => setMenuOpen(false)}>
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-nova-subtext">
            <p className="text-sm">Start the conversation</p>
          </div>
        )}

        {messages.map((msg, i) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            isLast={i === messages.length - 1}
            onRegenerate={regenerate}
            isLoading={isLoading}
          />
        ))}

        {error && (
          <ErrorBanner error={error} onDismiss={() => setError(null)} />
        )}

        <div ref={messagesEndRef} />
      </div>

      <InputBar
        onSend={sendMessage}
        onPlusSelect={handlePlusSelect}
        onVoiceOrb={() => setVoiceOrbOpen(true)}
        isLoading={isLoading}
        onStop={stopGeneration}
      />

      <VoiceOrb
        open={voiceOrbOpen}
        onClose={() => setVoiceOrbOpen(false)}
        onTranscript={sendMessage}
      />
    </div>
  )
}
