import { useState, useCallback, useRef } from 'react'
import { Message, AIMode } from '@/types'
import { sendChatStream, sendChat } from '@/lib/api'
import { nanoid } from '@/lib/utils'

interface UseChatOptions {
  chatId: string
  mode?: AIMode
  onSave?: (message: Message) => void
}

export function useChat({ chatId, mode = 'chat', onSave }: UseChatOptions) {
  const [messages, setMessages] = useState<Message[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const abortRef = useRef(false)

  const sendMessage = useCallback(async (content: string, context?: string) => {
    if (!content.trim() || isLoading) return

    const userMsg: Message = {
      id: nanoid(),
      chat_id: chatId,
      role: 'user',
      content,
      mode,
      created_at: new Date().toISOString(),
    }

    const updatedMessages = [...messages, userMsg]
    setMessages(updatedMessages)
    setIsLoading(true)
    setError(null)
    onSave?.(userMsg)

    const assistantId = nanoid()
    const assistantMsg: Message = {
      id: assistantId,
      chat_id: chatId,
      role: 'assistant',
      content: '',
      mode,
      created_at: new Date().toISOString(),
    }

    setMessages(prev => [...prev, assistantMsg])
    abortRef.current = false

    const apiMessages = updatedMessages.map(m => ({
      role: m.role,
      content: m.content,
    }))

    let didStream = false

    try {
      await sendChatStream(
        { messages: apiMessages, mode, context },
        (chunk) => {
          if (abortRef.current) return
          didStream = true
          setMessages(prev =>
            prev.map(m =>
              m.id === assistantId ? { ...m, content: m.content + chunk } : m
            )
          )
        },
        () => {
          setIsLoading(false)
          setMessages(prev => {
            const final = prev.find(m => m.id === assistantId)
            if (final) onSave?.(final)
            return prev
          })
        },
        async (err) => {
          // Fallback to non-streaming
          if (!didStream) {
            try {
              const res = await sendChat({ messages: apiMessages, mode, context })
              setMessages(prev =>
                prev.map(m =>
                  m.id === assistantId ? { ...m, content: res.content } : m
                )
              )
              onSave?.({ ...assistantMsg, content: res.content })
            } catch (fallbackErr) {
              const msg = fallbackErr instanceof Error ? fallbackErr.message : 'Unknown error'
              setError(msg)
              setMessages(prev => prev.filter(m => m.id !== assistantId))
            }
          } else {
            console.warn('Stream error (partial):', err)
          }
          setIsLoading(false)
        }
      )
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to send message'
      setError(msg)
      setMessages(prev => prev.filter(m => m.id !== assistantId))
      setIsLoading(false)
    }
  }, [messages, chatId, mode, isLoading, onSave])

  const regenerate = useCallback(() => {
    const lastUser = [...messages].reverse().find(m => m.role === 'user')
    if (!lastUser) return
    setMessages(prev => {
      // findLastIndex not available in all envs, use reverse search
      let idx = -1
      for (let i = prev.length - 1; i >= 0; i--) {
        if (prev[i].role === 'assistant') { idx = i; break }
      }
      return idx >= 0 ? prev.slice(0, idx) : prev
    })
    sendMessage(lastUser.content)
  }, [messages, sendMessage])

  const clearMessages = useCallback(() => setMessages([]), [])

  const stopGeneration = useCallback(() => {
    abortRef.current = true
    setIsLoading(false)
  }, [])

  return {
    messages,
    setMessages,
    isLoading,
    error,
    setError,
    sendMessage,
    regenerate,
    clearMessages,
    stopGeneration,
  }
}
