import { Routes, Route } from 'react-router-dom'
import HomeScreen from './pages/HomeScreen'
import ChatScreen from './pages/ChatScreen'
import SettingsScreen from './pages/SettingsScreen'
import ImagesScreen from './pages/ImagesScreen'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<HomeScreen />} />
      <Route path="/chat/:chatId" element={<ChatScreen />} />
      <Route path="/settings" element={<SettingsScreen />} />
      <Route path="/images" element={<ImagesScreen />} />
    </Routes>
  )
}
