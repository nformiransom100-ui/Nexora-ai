// ─── Core Types ─────────────────────────────────────────────────────────────

export type AIMode =
  | 'chat'
  | 'code'
  | 'write'
  | 'analyze'
  | 'brainstorm'
  | 'advice'
  | 'summarize'
  | 'translate'
  | 'research'
  | 'search'
  | 'image'

export type MessageRole = 'user' | 'assistant' | 'system'

export interface Message {
  id: string
  chat_id: string
  role: MessageRole
  content: string
  mode?: AIMode
  attachments?: Attachment[]
  created_at: string
}

export interface Chat {
  id: string
  user_id: string
  title: string
  mode?: AIMode
  project_id?: string | null
  created_at: string
  updated_at: string
  messages?: Message[]
}

export interface Project {
  id: string
  user_id: string
  name: string
  description?: string
  created_at: string
}

export interface ProjectItem {
  id: string
  project_id: string
  type: 'chat' | 'file'
  ref_id: string
  created_at: string
}

export interface UploadedFile {
  id: string
  user_id: string
  name: string
  type: string
  size: number
  url?: string
  extracted_text?: string
  created_at: string
}

export interface GeneratedImage {
  id: string
  user_id: string
  prompt: string
  url: string
  created_at: string
}

export interface Memory {
  id: string
  user_id: string
  key: string
  value: string
  created_at: string
}

export interface Attachment {
  type: 'file' | 'image' | 'camera'
  name: string
  url?: string
  data?: string       // base64
  mimeType?: string
  extractedText?: string
}

// ─── API Types ───────────────────────────────────────────────────────────────

export interface ChatRequest {
  messages: { role: MessageRole; content: string }[]
  mode?: AIMode
  context?: string
  stream?: boolean
}

export interface SearchResult {
  title: string
  url: string
  content: string
  score?: number
}

export interface SearchResponse {
  query: string
  results: SearchResult[]
  summary: string
}

export interface ResearchReport {
  topic: string
  summary: string
  keyFindings: string[]
  details: string
  sources: SearchResult[]
  finalAnswer: string
}

// ─── App State ───────────────────────────────────────────────────────────────

export interface AppUser {
  id: string
  email?: string
  isGuest: boolean
  preferences?: Record<string, string>
}

export type PlusMenuItem = 'camera' | 'photos' | 'files' | 'image' | 'research' | 'search'

export type SidebarView = 'chats' | 'projects' | 'images' | 'tools' | 'settings' | 'account'
