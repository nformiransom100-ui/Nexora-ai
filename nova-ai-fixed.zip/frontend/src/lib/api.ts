const API_URL = import.meta.env.VITE_API_URL || '/api'

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(err.error || `Request failed: ${res.status}`)
  }

  return res.json()
}

// ─── Chat ─────────────────────────────────────────────────────────────────────
export async function sendChat(body: {
  messages: { role: string; content: string }[]
  mode?: string
  context?: string
}) {
  return request<{ content: string }>('/api/chat', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

export async function sendChatStream(
  body: { messages: { role: string; content: string }[]; mode?: string; context?: string },
  onChunk: (chunk: string) => void,
  onDone: () => void,
  onError: (err: string) => void
) {
  try {
    const res = await fetch(`${API_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, stream: true }),
    })

    if (!res.ok || !res.body) {
      const err = await res.json().catch(() => ({ error: res.statusText }))
      onError(err.error || 'Stream failed')
      return
    }

    const reader = res.body.getReader()
    const decoder = new TextDecoder()

    while (true) {
      const { done, value } = await reader.read()
      if (done) { onDone(); break }
      const text = decoder.decode(value)
      // Parse SSE lines
      text.split('\n').forEach(line => {
        if (line.startsWith('data: ')) {
          const data = line.slice(6)
          if (data === '[DONE]') { onDone(); return }
          try {
            const json = JSON.parse(data)
            const chunk = json.choices?.[0]?.delta?.content || ''
            if (chunk) onChunk(chunk)
          } catch {}
        }
      })
    }
  } catch (err) {
    onError(err instanceof Error ? err.message : 'Stream error')
  }
}

// ─── Search ──────────────────────────────────────────────────────────────────
export async function webSearch(query: string) {
  return request<{ query: string; results: unknown[]; summary: string }>('/api/search', {
    method: 'POST',
    body: JSON.stringify({ query }),
  })
}

// ─── Deep Research ───────────────────────────────────────────────────────────
export async function deepResearch(topic: string) {
  return request<{ topic: string; summary: string; keyFindings: string[]; details: string; sources: unknown[]; finalAnswer: string }>('/api/deep-research', {
    method: 'POST',
    body: JSON.stringify({ topic }),
  })
}

// ─── Image Generation ────────────────────────────────────────────────────────
export async function generateImage(prompt: string) {
  return request<{ url: string; prompt: string }>('/api/image', {
    method: 'POST',
    body: JSON.stringify({ prompt }),
  })
}

// ─── File Upload ─────────────────────────────────────────────────────────────
export async function uploadFile(file: File) {
  const form = new FormData()
  form.append('file', file)
  const res = await fetch(`${API_URL}/api/file`, {
    method: 'POST',
    body: form,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(err.error || 'Upload failed')
  }
  return res.json() as Promise<{ text: string; name: string; type: string; preview?: unknown[][] }>
}

// ─── Vision ──────────────────────────────────────────────────────────────────
export async function analyzeImage(imageBase64: string, mimeType: string, prompt?: string) {
  return request<{ content: string }>('/api/vision', {
    method: 'POST',
    body: JSON.stringify({ image: imageBase64, mimeType, prompt }),
  })
}
