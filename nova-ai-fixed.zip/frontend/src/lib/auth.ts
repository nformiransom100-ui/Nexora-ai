import { AppUser } from '@/types'

const GUEST_ID_KEY = 'nova_guest_id'

function generateGuestId(): string {
  return 'guest_' + Math.random().toString(36).slice(2, 11) + Date.now().toString(36)
}

export function getOrCreateGuestUser(): AppUser {
  let id = localStorage.getItem(GUEST_ID_KEY)
  if (!id) {
    id = generateGuestId()
    localStorage.setItem(GUEST_ID_KEY, id)
  }
  return { id, isGuest: true }
}

export function clearGuestSession() {
  localStorage.removeItem(GUEST_ID_KEY)
}
