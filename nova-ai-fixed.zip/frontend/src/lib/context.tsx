import React, { createContext, useContext, useState, useEffect } from 'react'
import { AppUser, Chat, AIMode } from '@/types'
import { getOrCreateGuestUser } from '@/lib/auth'

interface AppContextValue {
  user: AppUser
  currentChat: Chat | null
  setCurrentChat: (chat: Chat | null) => void
  chats: Chat[]
  setChats: React.Dispatch<React.SetStateAction<Chat[]>>
  sidebarOpen: boolean
  setSidebarOpen: (v: boolean) => void
  currentMode: AIMode
  setCurrentMode: (m: AIMode) => void
  theme: 'dark' | 'light'
  toggleTheme: () => void
}

const AppContext = createContext<AppContextValue | null>(null)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user] = useState<AppUser>(getOrCreateGuestUser)
  const [currentChat, setCurrentChat] = useState<Chat | null>(null)
  const [chats, setChats] = useState<Chat[]>([])
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [currentMode, setCurrentMode] = useState<AIMode>('chat')
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')

  useEffect(() => {
    const saved = localStorage.getItem('nova_theme') as 'dark' | 'light' | null
    if (saved) setTheme(saved)
  }, [])

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
    localStorage.setItem('nova_theme', theme)
  }, [theme])

  const toggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark')

  return (
    <AppContext.Provider value={{
      user, currentChat, setCurrentChat,
      chats, setChats,
      sidebarOpen, setSidebarOpen,
      currentMode, setCurrentMode,
      theme, toggleTheme,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}
