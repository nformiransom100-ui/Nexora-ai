import { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.novaai.app',
  appName: 'Nova AI',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SpeechRecognition: {
      prompt: 'Speak now...',
      language: 'en-US',
      maxResults: 1,
      popup: false,
    },
    TextToSpeech: {
      speechRate: 1.0,
      pitchRate: 1.0,
    },
    Camera: {
      presentationStyle: 'fullscreen',
    },
  },
}

export default config
