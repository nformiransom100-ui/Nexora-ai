# Nova AI

A ChatGPT-style AI assistant app built with React + TypeScript (frontend) and Node.js + Express (backend). Mobile-first, dark-mode, Capacitor-ready for Android APK.

---

## Project Structure

```
nova-ai/
├── frontend/          # React + Vite + Tailwind + Capacitor
│   ├── src/
│   │   ├── components/   # UI components (chat, sidebar, voice, etc.)
│   │   ├── pages/        # Screen-level components
│   │   ├── hooks/        # Custom React hooks
│   │   ├── lib/          # Supabase, API client, utils, context
│   │   ├── types/        # TypeScript types
│   │   └── styles/       # Global CSS
│   ├── capacitor.config.ts
│   └── vite.config.ts
├── backend/           # Node.js + Express API
│   └── src/
│       ├── routes/       # chat, search, image, file, vision
│       └── lib/          # openrouter helper
├── supabase/
│   └── schema.sql        # Full DB schema + RLS policies
└── package.json          # Monorepo scripts
```

---

## Required API Keys

| Key | Where to get it |
|-----|----------------|
| `VITE_SUPABASE_URL` | [supabase.com](https://supabase.com) → Project Settings → API |
| `VITE_SUPABASE_ANON_KEY` | Same as above |
| `SUPABASE_URL` | Same (server-side copy) |
| `SUPABASE_ANON_KEY` | Same (server-side copy) |
| `OPENROUTER_API_KEY` | [openrouter.ai](https://openrouter.ai) → Keys |
| `TAVILY_API_KEY` | [tavily.com](https://tavily.com) → API Keys |
| `FLUX_API_KEY` | [fal.ai](https://fal.ai) → Dashboard → Keys |

---

## Setup on Replit

### 1. Add Secrets (Environment Variables)
Go to **Tools → Secrets** and add:

**Frontend secrets** (prefix with VITE_):
```
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
VITE_API_URL=http://localhost:3001
```

**Backend secrets**:
```
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_ANON_KEY=eyJ...
OPENROUTER_API_KEY=sk-or-...
TAVILY_API_KEY=tvly-...
FLUX_API_KEY=...
PORT=3001
```

### 2. Set Up Supabase Database
1. Go to [supabase.com](https://supabase.com), create a new project
2. Open **SQL Editor**
3. Paste the contents of `supabase/schema.sql`
4. Click **Run**

### 3. Install Dependencies
```bash
npm run install:all
```

### 4. Run the App
```bash
npm run dev
```
- Frontend: http://localhost:5173
- Backend: http://localhost:3001

---

## How to Test

### Test Chat
1. Open http://localhost:5173
2. Type a message in the input bar and press Send
3. AI should reply (requires `OPENROUTER_API_KEY`)

### Test Web Search
1. Tap the + menu → Web Search
2. Enter a query
3. Results + AI summary should appear (requires `TAVILY_API_KEY`)

### Test Image Generation
1. Tap the + menu → Create Image
2. Enter a prompt like "a futuristic city at night"
3. Image should appear (requires `FLUX_API_KEY`)

### Test File Upload
1. Tap + → Files
2. Upload a PDF, DOCX, TXT, CSV, or XLSX
3. File text is extracted and sent to AI for analysis

### Test Without API Keys
The app will show clear error messages like:
- "OpenRouter key missing"
- "Search key missing"
- "Image key missing"

---

## Build for Android (APK)

### Prerequisites
- Android Studio installed
- Java JDK 17+
- Node.js 18+

### Steps
```bash
cd frontend

# 1. Build the web app
npm run build

# 2. Add Android platform (first time only)
npm run cap:add

# 3. Sync web build to Android
npm run cap:sync

# 4. Open in Android Studio
npm run cap:open
```

In Android Studio:
- Click **Build → Generate Signed Bundle/APK**
- Choose **APK**
- Create or use a keystore
- Build a release APK

### Android Permissions (already in capacitor.config.ts)
- `INTERNET`
- `RECORD_AUDIO` — voice input
- `CAMERA` — camera capture
- `READ_MEDIA_IMAGES` — photo picker

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/chat` | Chat completion (streaming supported) |
| POST | `/api/search` | Web search via Tavily |
| POST | `/api/deep-research` | Multi-query research report |
| POST | `/api/image` | Image generation via fal.ai |
| POST | `/api/file` | File upload + text extraction |
| POST | `/api/vision` | Image analysis via OpenRouter |
| GET  | `/api/health` | Check API key status |

---

## What's Built (Scaffold)

✅ Full monorepo structure  
✅ Frontend: React + TypeScript + Tailwind + Vite  
✅ Capacitor config for Android  
✅ Backend: Express + TypeScript  
✅ All 6 API routes  
✅ OpenRouter streaming support  
✅ Supabase schema + RLS  
✅ TypeScript types  
✅ Global context + useChat hook  
✅ Guest mode (no login required)  
✅ API client with error handling  

## Next Steps (To Build)

- [ ] HomeScreen UI (quick actions, input bar)
- [ ] Chat screen (message bubbles, markdown, code blocks)
- [ ] Sidebar (recent chats, navigation)
- [ ] Plus menu (camera, files, search, image gen)
- [ ] Voice input + live voice orb
- [ ] Settings screen
- [ ] Projects screen
- [ ] Image gallery screen
